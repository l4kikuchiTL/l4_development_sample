package com.example.tabenow_manager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTokanrisha1();

//       Button button = findViewById(R.id.to_kanrisha1);
//       button.setOnClickListener(new MyOnClickListener());

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference();

        myRef.child("message").setValue("Hello, World!",null);

        MyValueEventListener listener = new MyValueEventListener();

        myRef.child("key").addValueEventListener(listener);

    }

//    class MyOnClickListener implements View.OnClickListener {
//        @Override
//        public void onClick(View view) {
//            Intent intent = new Intent(MainActivity.this, kanrisha1.class);
//            startActivity(intent);
//
//
////            TextView text = findViewById(R.id.textViewMessage);
////            text.setText("こんにちは　Android!");
//        }
//    }

    protected void setToMainActivity()
    {
        Button buttonToPage1 = this.findViewById(R.id.to_Main);
        buttonToPage1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, kanrisha1.class);
                startActivity(intent);
            }
        });
    }
    protected void setTokanrisha1()
    {
        Button buttonToPage2 = this.findViewById(R.id.to_kanrisha1);
        buttonToPage2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, kanrisha1.class);
                startActivity(intent);
            }
        });
    }


    class MyValueEventListener implements ValueEventListener {
        public void onDataChange(DataSnapshot snapshot) {
            String key = snapshot.getKey();
            Object value = snapshot.getValue();
            System.out.println("データを受信しました。" + key + "=" + value);
        }

        public void onCancelled(DatabaseError error) {
            System.out.println("データがキャンセルされました。" + error.toString());
        }
    }
}