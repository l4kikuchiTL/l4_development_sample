package com.example.tabenow_manager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class kanrisha4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kanrisha4);

//        Button buttonBackKanrisha3 = this.findViewById(R.id.back_kanrisha3);
//        buttonBackKanrisha3.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//
//
//            }
//        });

        Button buttonToKanrisha5 = findViewById(R.id.to_kanrisha5);


        buttonToKanrisha5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(kanrisha4.this, kanrisha5.class);
                startActivity(intent);
            }

        });
    }
}