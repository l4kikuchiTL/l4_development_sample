package day3;

public interface FactoryProduct {
    // 1000個ずつ生産する
    public void produceBy1000();
}
