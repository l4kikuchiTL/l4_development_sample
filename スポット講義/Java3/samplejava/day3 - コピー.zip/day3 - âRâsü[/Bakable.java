package day3;

public interface Bakable {
    public void bake();
}
