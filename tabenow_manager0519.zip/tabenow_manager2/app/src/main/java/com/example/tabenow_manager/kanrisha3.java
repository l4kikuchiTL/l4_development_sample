package com.example.tabenow_manager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class kanrisha3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kanrisha3);

        Button buttonBackKanrisha3 = this.findViewById(R.id.back_kanrisha2);
        buttonBackKanrisha3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();


            }
        });

        Button buttonToKanrisha4 = findViewById(R.id.to_kanrisha4);


        buttonToKanrisha4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(kanrisha3.this, kanrisha4.class);
                startActivity(intent);
            }

        });
    }
}


