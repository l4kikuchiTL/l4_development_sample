package com.example.tabenow_manager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class kanrisha5 extends AppCompatActivity {

    String valueString;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kanrisha5);

        //Input_sampleActivityからのtext情報を取得
        Intent intent = this.getIntent();
        String shop_text = intent.getStringExtra("sendText");
        //参照できるようにvalueStringに格納
        valueString = shop_text;

        Button buttonmenueitiran= findViewById(R.id.menueitiran);
        buttonmenueitiran.setOnClickListener(new MyOnClickListener());


        Button buttonmatininzu = findViewById(R.id.matininzu);
        buttonmatininzu.setOnClickListener(new MyOnClickListener1());

        Button buttonmenuetouroku = findViewById(R.id.menuetouroku);
        buttonmenuetouroku.setOnClickListener(new MyOnClickListener2());


    }

    class MyOnClickListener implements  View.OnClickListener{
        @Override
        public void onClick(View view){
            Intent intent = new Intent(kanrisha5.this, menueitiran.class);
            intent.putExtra("sendText_1",valueString);

            startActivity(intent);
        }
    }

    class MyOnClickListener1 implements  View.OnClickListener{
        @Override
        public void onClick(View view){
            Intent intent = new Intent(kanrisha5.this, matininzu.class);
            intent.putExtra("sendText_2",valueString);

            startActivity(intent);

        };
    }

    class MyOnClickListener2 implements  View.OnClickListener{
        @Override
        public void onClick(View view){
            Intent intent = new Intent(kanrisha5.this, menuetouroku.class);
            startActivity(intent);

        };
    }

}



