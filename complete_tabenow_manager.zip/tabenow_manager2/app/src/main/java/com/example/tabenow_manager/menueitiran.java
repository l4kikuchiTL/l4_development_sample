package com.example.tabenow_manager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.HashMap;

public class menueitiran extends AppCompatActivity {

    //ここでリストを定義
    ArrayList<String> list = new ArrayList<String>();
    ArrayList<String> fresh_list = new ArrayList<String>();
    ArrayList<String> no_stock_list = new ArrayList<String>();

    String valueString;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menueitiran);

        //Input_sampleActivityからのtext情報を取得
        Intent intent = this.getIntent();
        String shop_text = intent.getStringExtra("sendText_1");
        //参照できるようにvalueStringに格納
        valueString = shop_text;

        Button button = findViewById(R.id.button3);
        button.setOnClickListener(new MyOnClickListener());
//
    }
    class MyOnClickListener implements View.OnClickListener {
        @Override
        public void onClick(View view) {

            //databaseの名で参照
            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference reference = database.getReference("shop");

            //データベースの初期化
            reference.child(valueString).child("fresh").removeValue();
            reference.child(valueString).child("no_stock").removeValue();

            //商品情報（数は4個で固定）
            HashMap<String, String> all_map = new HashMap<String, String>();

            //radiobuttonの情報を参照(コロッケ)
            RadioGroup radioGroup_1 = (RadioGroup)findViewById(R.id.korokkeGroup);
            int checkedId_1 = radioGroup_1.getCheckedRadioButtonId();
            //出来立て
            if (checkedId_1 == R.id.radioButton7){
                //確認用
                //System.out.println("届いてるよ");
                all_map.put("コロッケ","fresh");
            }
            //品切れ
            else if (checkedId_1 == R.id.radioButton6){
                all_map.put("コロッケ","no_stock");
            }
            else{
                all_map.put("コロッケ","else");
            }

            //radiobuttonの情報を参照(たい焼き)
            RadioGroup radioGroup_2 = (RadioGroup)findViewById(R.id.taiyakiGroup);
            int checkedId_2 = radioGroup_2.getCheckedRadioButtonId();
            //出来立て
            if (checkedId_2 == R.id.radioButton7){
                //確認用
                //System.out.println("届いてるよ");
                all_map.put("たい焼き","fresh");
            }
            //品切れ
            else if (checkedId_2 == R.id.radioButton6){
                all_map.put("たい焼き","no_stock");
            }
            else{
                all_map.put("たい焼き","else");
            }

            //radiobuttonの情報を参照(ワッフル)
            RadioGroup radioGroup_3 = (RadioGroup)findViewById(R.id.waffuruGroup);
            int checkedId_3 = radioGroup_3.getCheckedRadioButtonId();
            //出来立て
            if (checkedId_3 == R.id.radioButton7){
                //確認用
                //System.out.println("届いてるよ");
                all_map.put("ワッフル","fresh");
            }
            //品切れ
            else if (checkedId_3 == R.id.radioButton6){
                all_map.put("ワッフル","no_stock");
            }
            else{
                all_map.put("ワッフル","else");
            }

            //radiobuttonの情報を参照(からあげ)
            RadioGroup radioGroup_4 = (RadioGroup)findViewById(R.id.karaageGroup);
            int checkedId_4 = radioGroup_4.getCheckedRadioButtonId();
            //出来立て
            if (checkedId_4 == R.id.radioButton2){
                //確認用
                //System.out.println("届いてるよ");
                all_map.put("からあげ","fresh");
            }
            //品切れ
            else if (checkedId_4 == R.id.radioButton){
                all_map.put("からあげ","no_stock");
            }
            else{
                all_map.put("からあげ","else");
            }

            //商品名をmapkeyとして検索し、各々のリストに格納
            for(String mapkey : all_map.keySet()){
                if (all_map.get(mapkey).equals("fresh")){
                    fresh_list.add(mapkey);
                }
                else if (all_map.get(mapkey).equals("no_stock")){
                    no_stock_list.add(mapkey);
                }
                else{
                    continue;
                }
            }

            //各々のcountを初期化
            int fresh_count = 0;
            int no_stock_count = 0;


            //データベースへ追記（fresh）
            if (fresh_list.size() >= 1){
                for (String fresh : fresh_list){
                    reference.child(valueString).child("fresh").child(Integer.toString(fresh_count)).setValue(fresh,null);
                    fresh_count += 1;
                }
            }

            //データベースへ追記（no_stock）
            if (no_stock_list.size() >= 1){
                for (String no_stock : no_stock_list){
                    reference.child(valueString).child("no_stock").child(Integer.toString(no_stock_count)).setValue(no_stock,null);
                    no_stock_count += 1;
                }
            }

        }
    }
}