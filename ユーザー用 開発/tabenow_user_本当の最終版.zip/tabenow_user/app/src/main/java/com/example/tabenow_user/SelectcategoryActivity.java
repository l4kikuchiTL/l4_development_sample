package com.example.tabenow_user;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SelectcategoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selectcategory);
    }
}