package com.example.tabenow_user;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.HashMap;

public class InputfirebaseActivity extends AppCompatActivity {
//     implements TextWatcher

    //ここでリストを定義
    ArrayList<String> list = new ArrayList<String>();
    ArrayList<String> fresh_list = new ArrayList<String>();
    ArrayList<String> no_stock_list = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inputfirebase);

        //リスナーを登録
//        EditText editText = findViewById(R.id.text1);
//        editText.addTextChangedListener(this);

        Button button = findViewById(R.id.button2);
        button.setOnClickListener(new MyOnClickListener());

        //databaseの名で参照
//        FirebaseDatabase database = FirebaseDatabase.getInstance();
//        DatabaseReference reference = database.getReference("shop");



        //手作業でデータベースに追加
//        User user_1 = new User("菊池卓哉",30);
//        User user_2 = new User("植村颯太",22);
//        User user_3 = new User("マイケルジャクソン",35);

//        DatabaseReference refName = database.getReference("info/user_1");
//        DatabaseReference reName = database.getReference("info/user_2");
//        DatabaseReference rName = database.getReference("info/user_3");
//
//        refName.setValue(user_1);
//        reName.setValue(user_2);
//        rName.setValue(user_3);

//        DatabaseReference reference = FirebaseDatabase.getInstance().getReference();
//        reference.child("key1").setValue("こんにちは",null);

    }

//    @Override
//    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
//    }
//
//    @Override
//    public void onTextChanged(CharSequence s, int start, int before, int count) {
//    }
//
//    @Override
//    public void afterTextChanged(Editable s) {
//        // テキスト変更後に変更されたテキストを取り出す
//        String inputStr= s.toString();
//        // 取得したテキストをログに出力
//        //Log.d("テスト",inputStr);
//        System.out.println(inputStr);
//    }

    //edittextの入力内容をボタン押した文字列でtextに格納
    class MyOnClickListener implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            //databaseの名で参照
            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference reference = database.getReference("shop");


            //edittextの情報を入手
            EditText editText_1 = findViewById(R.id.shop_name);
            String shop_text = editText_1.getText().toString();
            //System.out.println(shop_text);
            EditText editText_2 = findViewById(R.id.wait_time);
            String wait_text = editText_2.getText().toString();
            //System.out.println(wait_text);

            //データベースの初期化
            reference.child(shop_text).removeValue();

            //データベースへ追記（待ち人数）
            reference.child(shop_text).child("wait").setValue(wait_text,null);


            //（仮）商品情報（数は６個で固定）
            HashMap<String, String> all_map = new HashMap<String, String>();
            //６個の商品の出来上がり情報を取得にall_mapに追加する
            all_map.put("商品Ａ","fresh");
            all_map.put("商品Ｂ","no_stock");
            all_map.put("商品Ｃ","fresh");
            all_map.put("商品Ｄ","no_stock");
            all_map.put("商品Ｅ","fresh");
            all_map.put("商品Ｆ","no_stock");

            //商品名をmapkeyとして検索し、各々のリストに格納
            for(String mapkey : all_map.keySet()){
                if (all_map.get(mapkey).equals("fresh")){
                    fresh_list.add(mapkey);
                }
                else if (all_map.get(mapkey).equals("no_stock")){
                    no_stock_list.add(mapkey);
                }
                else{
                    continue;
                }
            }

            //各々のcountを初期化
            int fresh_count = 0;
            int no_stock_count = 0;

            //データベースへ追記（fresh）
            if (fresh_list.size() >= 1){
                for (String fresh : fresh_list){
                    reference.child(shop_text).child("fresh").child(Integer.toString(fresh_count)).setValue(fresh,null);
                    fresh_count += 1;
                }
            }

            //データベースへ追記（no_stock）
            if (no_stock_list.size() >= 1){
                for (String no_stock : no_stock_list){
                    reference.child(shop_text).child("no_stock").child(Integer.toString(no_stock_count)).setValue(no_stock,null);
                    no_stock_count += 1;
                }
            }

        }
    }

//    public static class User{
//        public String name;
//        public Integer age;
//
//        public User(){
//        }
//
//        public User(String _name, Integer _age){
//            name = _name;
//            age = _age;
//        }
//
//        public String getName(){
//            return name;
//        }
//
//        public Integer getAge() {
//            return age;
//        }
//    }

}