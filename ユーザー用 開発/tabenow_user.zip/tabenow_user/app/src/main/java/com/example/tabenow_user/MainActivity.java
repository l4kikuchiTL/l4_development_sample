package com.example.tabenow_user;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //setTitle( "onajidane" );

        Button button = findViewById(R.id.button_gotocategory);
        button.setOnClickListener(new MyOnClickListener());

        Button button2 = findViewById(R.id.button_gotowaitingtime);
        button2.setOnClickListener(new MyOnClickListener1());

        Button button3 = findViewById(R.id.search_button);
        button3.setOnClickListener(new MyOnClickListener2());

        ImageButton button4 = findViewById(R.id.WaitingTime_Button);
        button4.setOnClickListener(new MyOnClickListener3());

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference();

        myRef.child("message_1").setValue("おりおりおりろろろろろろろおおろおろろっろお",null);

        MyValueEventListener listener = new MyValueEventListener();

        myRef.child("key").addValueEventListener(listener);

    }

    class MyOnClickListener implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(MainActivity.this, SelectcategoryActivity.class);
            startActivity(intent);
        }
    }

    class MyOnClickListener1 implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(MainActivity.this, SearchwaitingtimeActivity.class);
            startActivity(intent);
        }
    }

    class MyOnClickListener2 implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(MainActivity.this, OutputfirebaseActivity.class);
            EditText editText = findViewById(R.id.SearchBar);
            String text = editText.getText().toString();
            //System.out.println(text);

            //textの内容をOutputfirebaseActivityに送信
            intent.putExtra("sendText",text);
            startActivity(intent);
        }
    }

    class MyOnClickListener3 implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(MainActivity.this, ScrollviewShopDatail.class);
            startActivity(intent);
        }
    }

//    class MyOnClickListener implements View.OnClickListener {
//        @Override
//        public void onClick(View view) {
//            Intent intent = new Intent(MainActivity.this, MainActivity2.class);
//            startActivity(intent);
//
//
//            TextView text = findViewById(R.id.textViewMessage);
//            text.setText("こんにちは　Android!");
//        }
//    }

    class MyValueEventListener implements ValueEventListener {
        public void onDataChange(DataSnapshot snapshot) {
            String key = snapshot.getKey();
            Object value = snapshot.getValue();
            System.out.println("データを受信しました。" + key + "=" + value);
        }

        public void onCancelled(DatabaseError error) {
            System.out.println("データがキャンセルされました。" + error.toString());
        }
    }
}