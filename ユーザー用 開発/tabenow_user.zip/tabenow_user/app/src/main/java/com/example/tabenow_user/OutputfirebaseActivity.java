package com.example.tabenow_user;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;

public class OutputfirebaseActivity extends AppCompatActivity {

    //ここでリストを定義
    ArrayList<String> list = new ArrayList<String>();
    ArrayList<String> fresh_list = new ArrayList<String>();
    ArrayList<String> no_stock_list = new ArrayList<String>();

    String valueString;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_outputfirebase);

        //Input_sampleActivityからのtext情報を取得
        Intent intent = this.getIntent();
        String text = intent.getStringExtra("sendText");
        //参照できるようにvalueStringに格納
        valueString = text;
        //確認用
        //System.out.println(valueString);


        //firebaseからのデータ受信
        MyValueEventListener listener = new MyValueEventListener();

        FirebaseDatabase database_out = FirebaseDatabase.getInstance();
        DatabaseReference reference = database_out.getReference("shop");

        //参照先の情報をすべて持ってくる
        reference.addValueEventListener(listener);

        //子ノードの名前をリスト化
//        String[] subjects = {"user_1", "user_2", "user_3",};
//
//        for (String subject : subjects){
//            reference.child(subject).child("age").addValueEventListener(listener);
//            reference.child(subject).child("name").addValueEventListener(listener);
//        }
    }

    class MyValueEventListener implements ValueEventListener {
        public void onDataChange(DataSnapshot snapshot) {
            String key = snapshot.getKey();
            Object value = snapshot.getValue();

            //valueがHashMapだったら実行(佐々木さんのコード)
//            if (value instanceof HashMap) {
//                HashMap valueMap = (HashMap)value;
//
//                Log.d("Tabenow","" + valueMap.keySet().size());
//                for(Object mapkey : valueMap.keySet()) {
//                    Log.d("Tabenow","key:" + mapkey + " value: "+ valueMap.get(mapkey));
//                }
//            }

            System.out.println("データを受信しました。" + key + "=" + value);

            //valueがHashMapだったら実行
            if (value instanceof HashMap) {
                HashMap valueMap = (HashMap)value;

                //valueMapの要素数表示（店舗の数）
                Log.d("Tabenow","" + valueMap.keySet().size());
                //mapkeyは店名にあたる
                for(Object mapkey : valueMap.keySet()) {
                    Log.d("Tabenow","key:" + mapkey + " value: "+ valueMap.get(mapkey));

                    String strkey = mapkey.toString();
                    //ここで表示させたい店名を指定
                    boolean hantei = strkey.equals(valueString);
                    //表示させたい店名だった場合の処理
                    if (hantei){
                        Object sub_value = valueMap.get(mapkey);
                        HashMap sub_valueMap = (HashMap)sub_value;
                        //一店舗におけるデータ数（３つ）表示
                        Log.d("Tabenow_sub","" + sub_valueMap.keySet().size());
                        //sub_mapkeyは(fresh,no_stock,wait)の３つの値をとる
                        for(Object sub_mapkey : sub_valueMap.keySet()){
                            Log.d("Tabenow_sub","key:" + sub_mapkey + " value: "+ sub_valueMap.get(sub_mapkey));
                            if (sub_mapkey.toString().equals("fresh")){
                                //辞書型だった場合
//                                Object fresh_value = sub_valueMap.get(sub_mapkey);
//                                HashMap fresh_valueMap = (HashMap)fresh_value;
//                                for(Object fresh_mapkey : fresh_valueMap.keySet()){
//                                    fresh_list.add(fresh_valueMap.get(fresh_mapkey).toString());

                                //リストだった場合
                                Object fresh_value = sub_valueMap.get(sub_mapkey);
                                ArrayList fresh_valueList = (ArrayList)fresh_value;
                                for (Object fresh_menu : fresh_valueList){
                                    fresh_list.add(fresh_menu.toString());
                                }
                            }
                            else if (sub_mapkey.toString().equals("no_stock")){
                                //辞書型だった場合
//                                Object no_stock_value = sub_valueMap.get(sub_mapkey);
//                                HashMap no_stock_valueMap = (HashMap)no_stock_value;
//                                for(Object no_stock_mapkey : no_stock_valueMap.keySet()) {
//                                    no_stock_list.add(no_stock_valueMap.get(no_stock_mapkey).toString());

                                //リストだった場合
                                Object no_stock_value = sub_valueMap.get(sub_mapkey);
                                ArrayList no_stock_valueList = (ArrayList)no_stock_value;
                                for (Object no_stock_menu : no_stock_valueList){
                                    no_stock_list.add(no_stock_menu.toString());
                                }
                            }
                            else{
                                list.add(sub_valueMap.get(sub_mapkey).toString());
                            }
                        }
                    }
                }
            }

            if (fresh_list.size() >= 1) {
                //fresh_listの要素を文字列に変換する
                String fresh_str = String.join("\n", fresh_list);


                //textの文字を画面に出力する
                TextView text_1 = findViewById(R.id.textView_out_1);
                text_1.setText(valueString);
                TextView text_2 = findViewById(R.id.textView_out_2);
                text_2.setText("現在" + list.get(0) + "人待ち");
                TextView text_3 = findViewById(R.id.textView_out_3);
                text_3.setText(fresh_str);
                TextView text_5 = findViewById(R.id.search_result);
                text_5.setText("検索結果　１件");
            }

            if (no_stock_list.size() >= 1){
                //no_stock_listの要素を文字列に変換する
                String no_stock_str = String.join("\n", no_stock_list);

                //textの文字を画面に出力する
                TextView text_1 = findViewById(R.id.textView_out_1);
                text_1.setText(valueString);
                TextView text_2 = findViewById(R.id.textView_out_2);
                text_2.setText("現在" + list.get(0) + "人待ち");
                TextView text_4 = findViewById(R.id.textView_out_4);
                text_4.setText(no_stock_str);
                TextView text_5 = findViewById(R.id.search_result);
                text_5.setText("検索結果　１件");
            }

        }

        public void onCancelled(DatabaseError error) {
            System.out.println("データがキャンセルされました。" + error.toString());
        }
    }



}