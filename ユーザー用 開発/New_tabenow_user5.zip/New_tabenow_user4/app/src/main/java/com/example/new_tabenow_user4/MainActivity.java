package com.example.new_tabenow_user4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //setTitle( "onajidane" );

        Button button = findViewById(R.id.button_gotocategory);
        button.setOnClickListener(new MyOnClickListener());

        Button button2 = findViewById(R.id.button_gotowaitingtime);
        button2.setOnClickListener(new MyOnClickListener1());

        Button button3 = findViewById(R.id.search_button);
        button3.setOnClickListener(new MyOnClickListener2());

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference();

        myRef.child("message_1").setValue("おりおりおりろろろろろろろおおろおろろっろお",null);

        MyValueEventListener listener = new MyValueEventListener();

        myRef.child("key").addValueEventListener(listener);
    }

    class MyOnClickListener implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(MainActivity.this, SelectCategoryActivity.class);
            startActivity(intent);
        }
    }

    class MyOnClickListener1 implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(MainActivity.this, SearchingWaitingTimeActivity.class);
            startActivity(intent);
        }
    }

    class MyOnClickListener2 implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(MainActivity.this, SearchResultActivity.class);
            startActivity(intent);
        }
    }

    class MyValueEventListener implements ValueEventListener {
        public void onDataChange(DataSnapshot snapshot) {
            String key = snapshot.getKey();
            Object value = snapshot.getValue();
            System.out.println("データを受信しました。" + key + "=" + value);
        }

        public void onCancelled(DatabaseError error) {
            System.out.println("データがキャンセルされました。" + error.toString());
        }
    }
}