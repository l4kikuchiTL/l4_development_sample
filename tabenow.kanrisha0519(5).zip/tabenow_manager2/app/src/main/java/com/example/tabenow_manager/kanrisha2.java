package com.example.tabenow_manager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class kanrisha2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kanrisha2);

        Button buttonBackKanrisha2 = this.findViewById(R.id.back_kanrisha1);
        buttonBackKanrisha2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();


            }
        });

        Button buttonToKanrisha3 = findViewById(R.id.to_kanrisha3);


        buttonToKanrisha3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(kanrisha2.this, kanrisha3.class);
                startActivity(intent);

            }
        });
//        buttonToKanrisha2.setOnClickListener(new OnClickListener1());

    };





//
//    protected void setTokanrisha1()
//    {
//        Button buttonToPage3 = this.findViewById(R.id.to_Main);
//        buttonToPage3.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View v) {
//                setContentView(R.layout.activity_main);
//                setTokanrisha1();
//            }
//        });
//    }
//    protected void setTokanrisha1()
//    {
//        Button buttonToPage4 = this.findViewById(R.id.to_kanrisha1);
//        buttonToPage4.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View v) {
//                setContentView(R.layout.activity_kanrisha1);
//                setToMainActivity();
//            }
//        });
//    }
}