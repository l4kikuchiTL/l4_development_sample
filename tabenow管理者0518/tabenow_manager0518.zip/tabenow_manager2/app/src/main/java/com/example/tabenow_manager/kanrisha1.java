package com.example.tabenow_manager;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class kanrisha1 extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kanrisha1);
    }

    protected void setToMainActivity()
    {
        Button buttonToPage1 = this.findViewById(R.id.to_Main);
        buttonToPage1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                setContentView(R.layout.activity_main);
                setTokanrisha1();
            }
        });
    }
    protected void setTokanrisha1()
    {
        Button buttonToPage2 = this.findViewById(R.id.to_kanrisha1);
        buttonToPage2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                setContentView(R.layout.activity_kanrisha1);
                setToMainActivity();
            }
        });
    }
}