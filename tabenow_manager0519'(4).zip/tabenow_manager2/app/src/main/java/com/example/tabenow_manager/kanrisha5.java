package com.example.tabenow_manager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class kanrisha5 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kanrisha5);

        Button buttonmenueitiran= findViewById(R.id.menueitiran);
        buttonmenueitiran.setOnClickListener(new MyOnClickListener());


        Button buttonmatininzu = findViewById(R.id.matininzu);
        buttonmatininzu.setOnClickListener(new MyOnClickListener1());


    }

    class MyOnClickListener implements  View.OnClickListener{
        @Override
        public void onClick(View view){
            Intent intent = new Intent(kanrisha5.this, kanrisha6.class);
            startActivity(intent);
        }
    }

    class MyOnClickListener1 implements  View.OnClickListener{
        @Override
        public void onClick(View view){
            Intent intent = new Intent(kanrisha5.this, kanrisha7.class);
            startActivity(intent);

        };
    }
}



