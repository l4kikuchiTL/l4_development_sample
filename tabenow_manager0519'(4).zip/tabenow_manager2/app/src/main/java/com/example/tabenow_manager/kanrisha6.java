package com.example.tabenow_manager;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class kanrisha6 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kanrisha6);
    }
}