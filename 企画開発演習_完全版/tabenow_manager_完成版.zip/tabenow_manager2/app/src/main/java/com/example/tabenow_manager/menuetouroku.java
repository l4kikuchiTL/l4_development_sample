package com.example.tabenow_manager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class menuetouroku extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menuetouroku);

        Button buttonbutton = findViewById(R.id.button);
        buttonbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(menuetouroku.this, kanryogamen_menuetouroku.class);


                startActivity(intent);
            }
        });
    }
}
