package com.example.tabenow_user;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Input_sampleActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input_sample);

        Button button = findViewById(R.id.shop_button1);
        button.setOnClickListener(new MyOnClickListener_1());
    }

    //edittextの入力内容をボタン押した文字列でtextに格納
    class MyOnClickListener_1 implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(Input_sampleActivity.this, OutputfirebaseActivity.class);
            //edittextの文章をtextに格納
            EditText editText = findViewById(R.id.edit_sample);
            String text = editText.getText().toString();
            //System.out.println(text);

            //textの内容をOutputfirebaseActivityに送信
            intent.putExtra("sendText",text);
            startActivity(intent);
        }
    }
}