package com.example.tabenow_manager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class kanrisha1 extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kanrisha1);


        Button buttonBackKanrisha1 = this.findViewById(R.id.back_kanrisha1);
        buttonBackKanrisha1.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v) {
//                setContentView(R.layout.activity_kanrisha1);
//                setTokanrisha2();
            }
        });

        Button buttonToKanrisha2 = findViewById(R.id.to_kanrisha2);
        buttonToKanrisha2.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(kanrisha1.this, kanrisha2.class);
                startActivity(intent);
            }
        });



    }

    protected void setTokanrisha1()
    {
        Button buttonToPage3 = this.findViewById(R.id.back_kanrisha1);
        buttonToPage3.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v) {
//                setContentView(R.layout.activity_kanrisha1);
//                setTokanrisha2();
            }
        });
    }

    class MyOnClickListener1 implements View.OnClickListener {
        public void onClick(View view) {
            Intent intent = new Intent(kanrisha1.this, kanrisha2.class);
            startActivity(intent);
        }
    }
}
//    protected void setTokanrisha2()
//    {
//        Button buttonToPage4 = this.findViewById(R.id.to_kanrisha2);
//        buttonToPage4.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View v) {
//                setContentView(R.layout.activity_kanrisha2);
//                setTokanrisha1();
//            }
//        });
////    }
