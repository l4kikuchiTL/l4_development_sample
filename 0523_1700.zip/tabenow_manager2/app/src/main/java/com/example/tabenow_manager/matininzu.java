package com.example.tabenow_manager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class matininzu extends AppCompatActivity {

    String valueString;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.matininzu);

        //Input_sampleActivityからのtext情報を取得
        Intent intent = this.getIntent();
        String shop_text = intent.getStringExtra("sendText_2");
        //参照できるようにvalueStringに格納
        valueString = shop_text;

        Button button = findViewById(R.id.ninzutouroku);
        button.setOnClickListener(new MyOnClickListener());

    }

    class MyOnClickListener implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            //確認用
            //System.out.println("店名は" + valueString);

            //databaseの名で参照
            FirebaseDatabase database = FirebaseDatabase.getInstance();
            DatabaseReference reference = database.getReference("shop");

            //radiobuttonの情報を参照
//            RadioGroup radioGroup = (RadioGroup)findViewById(R.id.radioGroup);
//            radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener(){
//                @Override
//                public void onCheckedChanged(RadioGroup group, int checkedId){
//                    if (checkedId == R.id.radioButton12){
//                        //確認用
//                        //System.out.println("届いてるよ");
//                        //データベースへ追記（待ち人数）
//                        reference.child(valueString).child("wait").setValue("1~2", null);
//                    }
//                    if (checkedId == R.id.radioButton35){
//                        //データベースへ追記（待ち人数）
//                        reference.child(valueString).child("wait").setValue("3~5", null);
//                    }
//                    if (checkedId == R.id.radioButton69){
//                        //データベースへ追記（待ち人数）
//                        reference.child(valueString).child("wait").setValue("6~9", null);
//                    }
//                    if (checkedId == R.id.radioButton10){
//                        //データベースへ追記（待ち人数）
//                        reference.child(valueString).child("wait").setValue("10", null);
//                    }
//                }
//            });

            //radiobuttonの情報を参照
            RadioGroup radioGroup = (RadioGroup)findViewById(R.id.radioGroup);
            int checkedId = radioGroup.getCheckedRadioButtonId();
            if (checkedId == R.id.radioButton12){
                //確認用
                //System.out.println("届いてるよ");
                //データベースへ追記（待ち人数）
                reference.child(valueString).child("wait").setValue("1~2", null);
            }
            if (checkedId == R.id.radioButton35){
                //データベースへ追記（待ち人数）
                reference.child(valueString).child("wait").setValue("3~5", null);
            }
            if (checkedId == R.id.radioButton69){
                //データベースへ追記（待ち人数）
                reference.child(valueString).child("wait").setValue("6~9", null);
            }
            if (checkedId == R.id.radioButton10){
                //データベースへ追記（待ち人数）
                reference.child(valueString).child("wait").setValue("10", null);
            }



            //radioGroup.check(R.id.radioGroup_tag);

        }
    }
}