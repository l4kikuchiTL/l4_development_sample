package com.example.tabenow_manager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class kanrisha4 extends AppCompatActivity {

    String valueString;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kanrisha4);

        //Input_sampleActivityからのtext情報を取得
        Intent intent = this.getIntent();
        String shop_text = intent.getStringExtra("sendText");
        //参照できるようにvalueStringに格納
        valueString = shop_text;

//        Button buttonBackKanrisha3 = this.findViewById(R.id.back_kanrisha3);
//        buttonBackKanrisha3.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                finish();
//
//
//            }
//        });

        Button buttonToKanrisha5 = findViewById(R.id.to_kanrisha5);


        buttonToKanrisha5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(kanrisha4.this, kanrisha5.class);

                intent.putExtra("sendText",valueString);
                startActivity(intent);
            }

        });
    }
}