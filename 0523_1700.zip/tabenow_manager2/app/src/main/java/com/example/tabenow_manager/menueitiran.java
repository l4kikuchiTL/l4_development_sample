package com.example.tabenow_manager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class menueitiran extends AppCompatActivity {

    String valueString;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menueitiran);

        //Input_sampleActivityからのtext情報を取得
        Intent intent = this.getIntent();
        String shop_text = intent.getStringExtra("sendText_1");
        //参照できるようにvalueStringに格納
        valueString = shop_text;

//        Button button = findViewById(R.id.button3);
//        button.setOnClickListener(new MyOnClickListener());
//
    }
}